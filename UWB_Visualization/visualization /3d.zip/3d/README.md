## Usage
```
cd <current_dir>
./serverup.py 8888
```

You can access the web app in your browser at ```http://127.0.0.1:8888```
