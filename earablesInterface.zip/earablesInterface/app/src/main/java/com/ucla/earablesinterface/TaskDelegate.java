package com.ucla.earablesinterface;

public interface TaskDelegate {
    public void taskCompletionResult(String res);
}